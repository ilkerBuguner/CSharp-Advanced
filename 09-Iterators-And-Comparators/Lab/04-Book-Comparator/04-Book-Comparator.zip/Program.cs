﻿using System;

namespace IteratorsAndComparators
{
    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
