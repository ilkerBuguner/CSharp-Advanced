﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Tire
    {
        public double Pressure { get; set; }
        public int Age { get; set; }

    }
}
